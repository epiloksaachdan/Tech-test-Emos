package com.example.latihsan

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.latihsan.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        val email = binding.etEmail.toString()
        val password = binding.etPassword.toString()
        binding.btnLogin.setOnClickListener {
            intent = Intent(this,SecondPage::class.java)
            intent.putExtra("email",email)
            if (email.length >=10 && email.length <= 15 ) {
                if (email.contains("@")){
                    startActivity(intent)
                }
            }
        }
    }
}