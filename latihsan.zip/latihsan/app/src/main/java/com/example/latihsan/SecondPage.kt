package com.example.latihsan

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class SecondPage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second_page)
    }
}